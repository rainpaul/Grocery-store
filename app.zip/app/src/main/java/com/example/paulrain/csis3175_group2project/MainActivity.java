package com.example.paulrain.csis3175_group2project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button btnSignIn = findViewById(R.id.btnSignIn);
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText eTAcc = findViewById(R.id.txtAcc);
                final String sAcc = eTAcc.getText().toString();
                EditText eTPass = findViewById(R.id.txtPassword);
                final String sPass = eTPass.getText().toString();
                if ( sAcc.compareTo("") == 0 && sPass.compareTo("") == 0){
                    startActivity( new Intent(MainActivity.this, EnterPostalCode.class));
                }
            }
        });

    }

    public void createAcc(View view) {
        RadioButton radSignIn = findViewById(R.id.radLogin);
        radSignIn.setChecked(true);
        startActivity( new Intent( MainActivity.this,CreateAccountActivity.class));


    }

    public void editAccount(View view) {
        startActivity(new Intent(MainActivity.this,EditAccountActivity.class));
    }
}
