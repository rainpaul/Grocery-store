package com.example.paulrain.csis3175_group2project;

import android.content.Intent;
import android.database.MatrixCursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class ShowItemList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_item_list);
        initListView();
        Button btnProceed = findViewById(R.id.btnProceedItems);
        btnProceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ShowItemList.this, Delivery.class));
            }
        });
    }

    private void initListView()
    {
        final String[] matrix  = { "_id", "itemName","itemDescription", "itemPrice","itemUnit","itemAmount" };
        final String[] columns = { "itemName","itemDescription", "itemPrice","itemUnit","itemAmount" };
        final int[]    layouts = { R.id.itemName,R.id.itemDescription, R.id.itemPrice,R.id.itemUnit,R.id.eTAmount };

        MatrixCursor cursor = new MatrixCursor(matrix);

        int key = 0;

        cursor.addRow(new Object[] { key++, "Apple", "Mexico apple, imported from Cancun","$3","lbs","" });
        cursor.addRow(new Object[] { key++, "Apple", "Mexico apple, imported from Cancun","$3","lbs","" });
        cursor.addRow(new Object[] { key++, "Apple", "Mexico apple, imported from Cancun","$3","lbs","" });
        cursor.addRow(new Object[] { key++, "Apple", "Mexico apple, imported from Cancun","$3","lbs","" });
        cursor.addRow(new Object[] { key++, "Apple", "Mexico apple, imported from Cancun","$3","lbs","" });
        cursor.addRow(new Object[] { key++, "Apple", "Mexico apple, imported from Cancun","$3","lbs","" });
        cursor.addRow(new Object[] { key++, "Apple", "Mexico apple, imported from Cancun","$3","lbs","" });
        cursor.addRow(new Object[] { key++, "Apple", "Mexico apple, imported from Cancun","$3","lbs","" });

        SimpleCursorAdapter data =
                new SimpleCursorAdapter(this,
                        R.layout.listview_layout,
                        cursor,
                        columns,
                        layouts);
        ListView lv = findViewById(R.id.itemListView);
        lv.setAdapter( data );

    }

    public void editAcc(View view){
        startActivity(new Intent(this,EditAccountActivity.class));
    }

    public void logOut(View view){
        startActivity(new Intent(this,MainActivity.class));
    }

    public void inviteFriends(View view){
        startActivity(new Intent(this,InviteFriends.class));
    }

    public void showOrderHistory(View view){
        startActivity(new Intent(this,ShowOrderHistory.class));
    }

}
