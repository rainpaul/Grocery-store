package com.example.paulrain.csis3175_group2project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class PaymentMethod extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_method);
        Button btnProceed = findViewById(R.id.btnProceedPayment);
        btnProceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText eTName = findViewById(R.id.eTName);
                EditText eTNum = findViewById(R.id.eTNum);
                EditText eTCVV = findViewById(R.id.eTCVV);
                EditText eTExpire = findViewById(R.id.eTExpiredDate);
                String sName = eTName.getText().toString();
                String sNum = eTNum.getText().toString();
                String sCVV = eTCVV.getText().toString();
                String sExpire = eTExpire.getText().toString();

                if (sName.compareTo("") != 0 && sNum.compareTo("") != 0 && sCVV.compareTo("") != 0 && sExpire.compareTo("") != 0){
                    startActivity(new Intent(PaymentMethod.this, OrderComplete.class));
                }
                else{
                    Toast.makeText(PaymentMethod.this, "Please fill in required fields!", Toast.LENGTH_LONG).show();
                }
            }
        });

        RadioButton raBuCash = findViewById(R.id.raBuCash);
        raBuCash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioButton raBuCre = findViewById(R.id.raBuCreCar);
                raBuCre.setChecked(true);
                startActivity(new Intent(PaymentMethod.this, OrderComplete.class));
            }
        });

    }

    public void editAcc(View view){
        startActivity(new Intent(this,EditAccountActivity.class));
    }

    public void logOut(View view){
        startActivity(new Intent(this,MainActivity.class));
    }

    public void inviteFriends(View view){
        startActivity(new Intent(this,InviteFriends.class));
    }

    public void showOrderHistory(View view){
        startActivity(new Intent(this,ShowOrderHistory.class));
    }
}
