package com.example.paulrain.csis3175_group2project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
        Button btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText eTUserName = findViewById(R.id.eTUserName);
                EditText eTPass = findViewById(R.id.eTPass);
                EditText eTRetyPass = findViewById(R.id.eTRePass);
                EditText eTAdd = findViewById(R.id.eTAdd);
                EditText eTPostal = findViewById(R.id.eTPostal);
                EditText eTPhone = findViewById(R.id.eTPhone);

                String sUserName = eTUserName.getText().toString();
                String sPass = eTPass.getText().toString();
                String sRetyPass = eTRetyPass.getText().toString();
                String sAdd = eTAdd.getText().toString();
                String sPostal = eTPostal.getText().toString();
                String sPhone = eTPhone.getText().toString();

                if (sUserName.compareTo("") != 0 && sPass.compareTo("") != 0 && sRetyPass.compareTo("") != 0 &&
                        sAdd.compareTo("") != 0 && sPostal.compareTo("") != 0 && sPhone.compareTo("") != 0){
                    if (sPass.compareTo(sRetyPass) != 0){
                        Toast.makeText(CreateAccountActivity.this,"Retype password does not match, please check!",Toast.LENGTH_LONG).show();
                        return;
                    }
                    Toast.makeText(CreateAccountActivity.this,"Register completed, moving to Sign in page",Toast.LENGTH_SHORT).show();

                    startActivity(new Intent(CreateAccountActivity.this,MainActivity.class));
                }
                else{
                    Toast.makeText(CreateAccountActivity.this,"Please fill in required fields", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
