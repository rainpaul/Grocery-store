package com.example.paulrain.csis3175_group2project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class Delivery extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery);
        RadioButton raBuPickup = findViewById(R.id.raBuPickup);
        RadioButton raBuDeliCur = findViewById(R.id.raBuDeliCurAdd);
        final RadioButton raBuDeliNew = findViewById(R.id.raBuNewAdd);
        raBuPickup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                raBuDeliNew.setChecked(true);
                startActivity( new Intent(Delivery.this, PaymentMethod.class));
            }
        });
        raBuDeliCur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                raBuDeliNew.setChecked(true);
                startActivity( new Intent(Delivery.this, PaymentMethod.class));
            }
        });

        Button btnNext = findViewById(R.id.btnNext);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText eTAdd = findViewById(R.id.eTAdd);
                EditText eTPostal = findViewById(R.id.eTPostal);
                EditText eTPhone = findViewById(R.id.eTPhone);
                String sAdd = eTAdd.getText().toString();
                String sPostal = eTPostal.getText().toString();
                String sPhone =  eTPhone.getText().toString();
                if (sAdd.compareTo("") != 0 && sPostal.compareTo("") != 0 && sPhone.compareTo("") != 0){
                    startActivity(new Intent(Delivery.this, PaymentMethod.class));
                }
                else{
                    Toast.makeText(Delivery.this,"Please fill in required field!",Toast.LENGTH_LONG).show();
                }
            }
        });


    }

    public void editAcc(View view){
        startActivity(new Intent(this,EditAccountActivity.class));
    }

    public void logOut(View view){
        startActivity(new Intent(this,MainActivity.class));
    }

    public void inviteFriends(View view){
        startActivity(new Intent(this,InviteFriends.class));
    }

    public void showOrderHistory(View view){
        startActivity(new Intent(this,ShowOrderHistory.class));
    }
}
