package com.example.paulrain.csis3175_group2project;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    final static String DATABASE_NAME = "NKM_Grocery.db";
    final static int DATABASE_VERSION = 1;
    final static String TABLE1_NAME = "Customer_table";
    final static String T1COL1 = "Customer_ID";
    final static String T1COL2 = "User_Name";
//    final static String T1COL3 = ""
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
